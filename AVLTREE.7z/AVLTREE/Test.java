public class Test {
    public static void main(String[] args) {
        AVLTree tree = new AVLTree();
        tree.insert(10);
        tree.insert(25);
        tree.insert(40);
        tree.insert(15);
        tree.insert(20);
        tree.insert(50);
        //Print the resulting tree
        System.out.println(tree.toString());
    }
}
