public class AVLTree {

    private Node root;

    public AVLTree() {
        root = null;
    }

    // Helper method to get height of a node
    private int height(Node node) {
        if (node == null) {
            return -1;
        } else {
            return node.height;
        }
    }

    // Helper method to get balance factor of a node
    private int balanceFactor(Node node) {
        if (node == null) {
            return 0;
        } else {
            return height(node.right) - height(node.left);
        }
    }

    // Helper method to update height of a node
    private void updateHeight(Node node) {
        node.height = Math.max(height(node.left), height(node.right)) + 1;
    }

    // Helper method to perform left rotation on a node
    private Node rotateLeft(Node node) {
        Node temp = node.right;
        node.right = temp.left;
        temp.left = node;
        updateHeight(node);
        updateHeight(temp);
        return temp;
    }

    // Helper method to perform right rotation on a node
    private Node rotateRight(Node node) {
        Node temp = node.left;
        node.left = temp.right;
        temp.right = node;
        updateHeight(node);
        updateHeight(temp);
        return temp;
    }

    // Helper method to balance a node
    private Node balance(Node node) {
        updateHeight(node);
        int balanceFactor = balanceFactor(node);
        if (balanceFactor > 1) {
            if (balanceFactor(node.right) < 0) {
                node.right = rotateRight(node.right);
            }
            return rotateLeft(node);
        } else if (balanceFactor < -1) {
            if (balanceFactor(node.left) > 0) {
                node.left = rotateLeft(node.left);
            }
            return rotateRight(node);
        }
        return node;
    }

    // Public method to insert a node into the AVL tree
    public void insert(int data) {
        root = insert(root, data);
    }

    // Helper method to insert a node into the AVL tree
    private Node insert(Node node, int data) {
        if (node == null) {
            return new Node(data);
        }
        if (data < node.data) {
            node.left = insert(node.left, data);
        } else if (data > node.data) {
            node.right = insert(node.right, data);
        } else {
            // Duplicate keys are not allowed in AVL tree
            throw new RuntimeException("Duplicate key!");
        }
        return balance(node);
    }

    // Public method to delete a node from the AVL tree
    public void delete(int data) {
        root = delete(root, data);
    }

    // Helper method to delete a node from the AVL tree
    private Node delete(Node node, int data) {
        if (node == null) {
            return null;
        }
        if (data < node.data) {
            node.left = delete(node.left, data);
        } else if (data > node.data) {
            node.right = delete(node.right, data);
        } else {
            if (node.left == null) {
                node = node.right;
            } else if (node.right == null) {
                node = node.left;
            }
        }
        return node;
    }


    public String toString() {
        return toStringHelper(root);
    }

    private String toStringHelper(Node node) {
        if(node == null) {
            return "";
        }
        String left = toStringHelper(node.left);
        String right = toStringHelper(node.right);
        return "(" + node.data + " " + left + " " + right + ")";
    }
}
       

