public class Node {
    int data;
    Node left;
    Node right;

    int height;
    public int key;

    //ctor
    public Node(int data) {
        this.data = data;
    }
}
